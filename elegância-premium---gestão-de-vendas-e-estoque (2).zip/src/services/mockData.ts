
export type User = {
  id: number;
  username: string;
  role: 'manager' | 'seller' | 'stockist';
  name: string;
};

export type Product = {
  id: number;
  name: string;
  price: number;
  stock: number;
};

export type Client = {
  id: number;
  name: string;
  phone: string;
};

export type SaleItem = {
  id: number;
  sale_id: number;
  product_id: number;
  quantity: number;
  price: number;
  product_name?: string;
};

export type Sale = {
  id: number;
  client_id: number;
  client_name?: string;
  total: number;
  date: string;
  user_id: number;
  items?: SaleItem[];
};

// Initial Data
const INITIAL_PRODUCTS: Product[] = [
  { id: 1, name: 'Camiseta Premium', price: 49.90, stock: 100 },
  { id: 2, name: 'Calça Jeans Elegance', price: 129.90, stock: 50 },
  { id: 3, name: 'Vestido de Seda', price: 189.90, stock: 30 },
  { id: 4, name: 'Blazer Slim Fit', price: 249.90, stock: 15 },
  { id: 5, name: 'Sapato Social Couro', price: 199.90, stock: 25 },
];

const INITIAL_CLIENTS: Client[] = [
  { id: 1, name: 'Consumidor Final', phone: '0000000000' },
  { id: 2, name: 'João Silva', phone: '11999999999' },
  { id: 3, name: 'Maria Oliveira', phone: '11888888888' },
];

const INITIAL_USERS: User[] = [
  { id: 1, username: 'maria', role: 'manager', name: 'Maria (Gerente)' },
  { id: 2, username: 'carlos', role: 'seller', name: 'Carlos (Vendedor)' },
  { id: 3, username: 'patricia', role: 'stockist', name: 'Patrícia (Estoquista)' },
];

// Helper to get data from localStorage
const getLocalData = <T>(key: string, initial: T): T => {
  const saved = localStorage.getItem(key);
  return saved ? JSON.parse(saved) : initial;
};

const saveLocalData = <T>(key: string, data: T) => {
  localStorage.setItem(key, JSON.stringify(data));
};

export const mockService = {
  // Auth
  login: (username: string): { user: User; token: string } | null => {
    const user = INITIAL_USERS.find(u => u.username === username);
    if (user) {
      return { user, token: 'mock-jwt-token' };
    }
    return null;
  },

  // Products
  getProducts: (): Product[] => getLocalData('mock_products', INITIAL_PRODUCTS),
  saveProduct: (product: Omit<Product, 'id'> & { id?: number }) => {
    const products = mockService.getProducts();
    if (product.id) {
      const index = products.findIndex(p => p.id === product.id);
      products[index] = { ...products[index], ...product } as Product;
    } else {
      const newId = products.length > 0 ? Math.max(...products.map(p => p.id)) + 1 : 1;
      products.push({ ...product, id: newId } as Product);
    }
    saveLocalData('mock_products', products);
  },
  deleteProduct: (id: number) => {
    const products = mockService.getProducts().filter(p => p.id !== id);
    saveLocalData('mock_products', products);
  },

  // Clients
  getClients: (): Client[] => getLocalData('mock_clients', INITIAL_CLIENTS),
  saveClient: (client: Omit<Client, 'id'> & { id?: number }) => {
    const clients = mockService.getClients();
    if (client.id) {
      const index = clients.findIndex(c => c.id === client.id);
      clients[index] = { ...clients[index], ...client } as Client;
    } else {
      const newId = clients.length > 0 ? Math.max(...clients.map(c => c.id)) + 1 : 1;
      clients.push({ ...client, id: newId } as Client);
    }
    saveLocalData('mock_clients', clients);
  },
  deleteClient: (id: number) => {
    const clients = mockService.getClients().filter(c => c.id !== id);
    saveLocalData('mock_clients', clients);
  },

  // Sales
  getSales: (): Sale[] => {
    const sales = getLocalData<Sale[]>('mock_sales', []);
    const clients = mockService.getClients();
    return sales.map(s => ({
      ...s,
      client_name: clients.find(c => c.id === s.client_id)?.name || 'Desconhecido'
    }));
  },
  saveSale: (saleData: { client_id: number; items: any[]; total: number; user_id?: number }) => {
    const sales = getLocalData<Sale[]>('mock_sales', []);
    const products = mockService.getProducts();
    
    // Check stock
    for (const item of saleData.items) {
      const product = products.find(p => p.id === item.product_id);
      if (!product || product.stock < item.quantity) {
        throw new Error(`Estoque insuficiente para ${product?.name || 'produto'}`);
      }
    }

    const newSaleId = sales.length > 0 ? Math.max(...sales.map(s => s.id)) + 1 : 1;
    const newSale: Sale = {
      id: newSaleId,
      client_id: saleData.client_id,
      total: saleData.total,
      date: new Date().toISOString(),
      user_id: saleData.user_id || 1,
    };

    sales.push(newSale);
    saveLocalData('mock_sales', sales);

    // Update stock
    const updatedProducts = products.map(p => {
      const item = saleData.items.find(i => i.product_id === p.id);
      if (item) {
        return { ...p, stock: p.stock - item.quantity };
      }
      return p;
    });
    saveLocalData('mock_products', updatedProducts);

    return newSaleId;
  },
  deleteSale: (id: number) => {
    const sales = getLocalData<Sale[]>('mock_sales', []);
    const sale = sales.find(s => s.id === id);
    if (!sale) return;

    // In a real mock we'd also restore stock if we tracked items, 
    // but for simplicity we'll just remove the sale record.
    const filteredSales = sales.filter(s => s.id !== id);
    saveLocalData('mock_sales', filteredSales);
  },

  // Dashboard
  getDashboardData: () => {
    const sales = mockService.getSales();
    const products = mockService.getProducts();
    const today = new Date().toISOString().split('T')[0];
    
    const totalSalesToday = sales
      .filter(s => s.date.startsWith(today))
      .reduce((acc, s) => acc + s.total, 0);
      
    const lowStockProducts = products.filter(p => p.stock < 10);
    const recentSales = sales.sort((a, b) => b.date.localeCompare(a.date)).slice(0, 5);

    return {
      totalSalesToday,
      lowStockProducts,
      recentSales
    };
  }
};
