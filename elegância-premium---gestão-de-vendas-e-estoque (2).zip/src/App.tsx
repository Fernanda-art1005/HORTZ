import { useState, useEffect } from 'react';
import { useAuth } from './contexts/AuthContext';
import { 
  LayoutDashboard, 
  Package, 
  Users, 
  ShoppingCart, 
  LogOut, 
  Menu, 
  X
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import Products from './components/Products';
import Clients from './components/Clients';
import PDV from './components/PDV';

type Tab = 'dashboard' | 'products' | 'clients' | 'pdv';

export default function App() {
  const { user, logout, isLoading } = useAuth();
  const [activeTab, setActiveTab] = useState<Tab>('pdv');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        setIsSidebarOpen(true);
        setIsMobileMenuOpen(false);
      } else {
        setIsSidebarOpen(false);
      }
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-zinc-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-600"></div>
      </div>
    );
  }

  if (!user) {
    return <Login />;
  }

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, roles: ['manager'] },
    { id: 'products', label: 'Estoque', icon: Package, roles: ['manager', 'stockist'] },
    { id: 'clients', label: 'Clientes', icon: Users, roles: ['manager', 'seller'] },
    { id: 'pdv', label: 'PDV / Vendas', icon: ShoppingCart, roles: ['manager', 'seller'] },
  ];

  const filteredMenuItems = menuItems.filter(item => item.roles.includes(user.role));

  // Set default tab if current is not allowed
  if (!filteredMenuItems.find(item => item.id === activeTab)) {
    setActiveTab(filteredMenuItems[0]?.id as Tab || 'pdv');
  }

  const SidebarContent = () => (
    <>
      <div className="p-6 flex items-center justify-between">
        {(isSidebarOpen || isMobileMenuOpen) && (
          <motion.h1 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-2xl font-bold text-orange-500 tracking-tighter"
          >
            ELEGÂNCIA PREMIUM
          </motion.h1>
        )}
        <button 
          onClick={() => setIsSidebarOpen(!isSidebarOpen)}
          className="hidden lg:block p-1 hover:bg-zinc-200 rounded text-zinc-500"
        >
          {isSidebarOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
        <button 
          onClick={() => setIsMobileMenuOpen(false)}
          className="lg:hidden p-1 hover:bg-zinc-200 rounded text-zinc-500"
        >
          <X size={24} />
        </button>
      </div>

      <nav className="flex-1 px-4 space-y-2 mt-4">
        {filteredMenuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => {
              setActiveTab(item.id as Tab);
              if (window.innerWidth < 1024) setIsMobileMenuOpen(false);
            }}
            className={`w-full flex items-center p-3 rounded-lg transition-colors ${
              activeTab === item.id 
                ? 'bg-orange-600 text-white shadow-lg shadow-orange-600/20' 
                : 'hover:bg-zinc-200 text-zinc-600'
            }`}
          >
            <item.icon size={20} />
            {(isSidebarOpen || isMobileMenuOpen) && <span className="ml-3 font-medium">{item.label}</span>}
          </button>
        ))}
      </nav>

      <div className="p-4 border-t border-zinc-200">
        <div className={`flex items-center ${(isSidebarOpen || isMobileMenuOpen) ? 'justify-between' : 'justify-center'}`}>
          {(isSidebarOpen || isMobileMenuOpen) && (
            <div className="overflow-hidden">
              <p className="text-sm font-semibold truncate text-zinc-900">{user.name}</p>
              <p className="text-xs text-zinc-500 capitalize">{user.role}</p>
            </div>
          )}
          <button 
            onClick={logout}
            className="p-2 hover:bg-zinc-200 rounded-full text-zinc-400 hover:text-red-600 transition-colors"
            title="Sair"
          >
            <LogOut size={20} />
          </button>
        </div>
      </div>
    </>
  );

  return (
    <div className="min-h-screen bg-zinc-50 flex flex-col lg:flex-row">
      {/* Mobile Header */}
      <header className="lg:hidden bg-[#f5f5f0] border-b border-zinc-200 p-4 flex items-center justify-between sticky top-0 z-40">
        <h1 className="text-xl font-bold text-orange-500 tracking-tighter">ELEGÂNCIA PREMIUM</h1>
        <button 
          onClick={() => setIsMobileMenuOpen(true)}
          className="p-2 text-zinc-600 hover:bg-zinc-200 rounded-lg"
        >
          <Menu size={24} />
        </button>
      </header>

      {/* Desktop Sidebar */}
      <aside 
        className={`hidden lg:flex ${
          isSidebarOpen ? 'w-64' : 'w-20'
        } bg-[#f5f5f0] text-zinc-900 border-r border-zinc-200 transition-all duration-300 flex-col fixed h-full z-50`}
      >
        <SidebarContent />
      </aside>

      {/* Mobile Sidebar Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMobileMenuOpen(false)}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[60] lg:hidden"
            />
            <motion.aside
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed inset-y-0 left-0 w-72 bg-[#f5f5f0] z-[70] flex flex-col shadow-2xl lg:hidden"
            >
              <SidebarContent />
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <main className={`flex-1 transition-all duration-300 ${isSidebarOpen ? 'lg:ml-64' : 'lg:ml-20'} p-4 md:p-8`}>
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            {activeTab === 'dashboard' && <Dashboard />}
            {activeTab === 'products' && <Products />}
            {activeTab === 'clients' && <Clients />}
            {activeTab === 'pdv' && <PDV />}
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
}
