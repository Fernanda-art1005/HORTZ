import express from "express";
console.log("Server starting...");
import { createServer as createViteServer } from "vite";
import path from "path";
import cors from "cors";
import Database from "better-sqlite3";
import crypto from "crypto";
import jwt from "jsonwebtoken";

const db = new Database("hortz.db");
db.pragma('foreign_keys = ON');
const JWT_SECRET = "hortz-secret-key-123";

// Initialize Database
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password TEXT,
    role TEXT, -- 'manager', 'seller', 'stockist'
    name TEXT
  );

  CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    price REAL,
    stock INTEGER
  );

  CREATE TABLE IF NOT EXISTS clients (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    phone TEXT
  );

  CREATE TABLE IF NOT EXISTS sales (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id INTEGER,
    total REAL,
    date DATETIME DEFAULT CURRENT_TIMESTAMP,
    user_id INTEGER,
    FOREIGN KEY(client_id) REFERENCES clients(id),
    FOREIGN KEY(user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS sale_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sale_id INTEGER,
    product_id INTEGER,
    quantity INTEGER,
    price REAL,
    FOREIGN KEY(sale_id) REFERENCES sales(id) ON DELETE CASCADE,
    FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE
  );
`);

// Initial Data
const seed = () => {
  const userCount = db.prepare("SELECT count(*) as count FROM users").get() as { count: number };
  if (userCount.count === 0) {
    const hash = (pw: string) => crypto.createHash('sha256').update(pw).digest('hex');
    
    db.prepare("INSERT INTO users (username, password, role, name) VALUES (?, ?, ?, ?)").run('maria', hash('123456'), 'manager', 'Maria (Gerente)');
    db.prepare("INSERT INTO users (username, password, role, name) VALUES (?, ?, ?, ?)").run('carlos', hash('123456'), 'seller', 'Carlos (Vendedor)');
    db.prepare("INSERT INTO users (username, password, role, name) VALUES (?, ?, ?, ?)").run('patricia', hash('123456'), 'stockist', 'Patrícia (Estoquista)');

    db.prepare("INSERT INTO clients (name, phone) VALUES (?, ?)").run('Consumidor Final', '0000000000');
    
    db.prepare("INSERT INTO products (name, price, stock) VALUES (?, ?, ?)").run('Camiseta', 49.90, 100);
    db.prepare("INSERT INTO products (name, price, stock) VALUES (?, ?, ?)").run('Calça Jeans', 129.90, 50);
    db.prepare("INSERT INTO products (name, price, stock) VALUES (?, ?, ?)").run('Vestido', 89.90, 30);
  }
};
seed();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(cors());
  app.use(express.json());

  app.get("/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Logger
  app.use((req, res, next) => {
    console.log(`${req.method} ${req.url}`);
    next();
  });

  // Auth Middleware
  const authenticate = (req: any, res: any, next: any) => {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) return res.status(401).json({ error: "Unauthorized" });
    try {
      const decoded = jwt.verify(token, JWT_SECRET);
      req.user = decoded;
      next();
    } catch (e) {
      res.status(401).json({ error: "Invalid token" });
    }
  };

  // Auth Routes
  app.post("/api/login", (req, res) => {
    const { username, password } = req.body;
    const hash = crypto.createHash('sha256').update(password).digest('hex');
    const user = db.prepare("SELECT * FROM users WHERE username = ? AND password = ?").get(username, hash) as any;
    
    if (user) {
      const token = jwt.sign({ id: user.id, username: user.username, role: user.role, name: user.name }, JWT_SECRET);
      res.json({ token, user: { id: user.id, username: user.username, role: user.role, name: user.name } });
    } else {
      res.status(401).json({ error: "Usuário ou senha incorretos" });
    }
  });

  // Products
  app.get("/api/products", authenticate, (req, res) => {
    const products = db.prepare("SELECT * FROM products").all();
    res.json(products);
  });

  app.post("/api/products", authenticate, (req: any, res) => {
    if (req.user.role !== 'manager' && req.user.role !== 'stockist') return res.status(403).json({ error: "Forbidden" });
    const { name, price, stock } = req.body;
    const result = db.prepare("INSERT INTO products (name, price, stock) VALUES (?, ?, ?)").run(name, price, stock);
    res.json({ id: result.lastInsertRowid });
  });

  app.put("/api/products/:id", authenticate, (req: any, res) => {
    if (req.user.role !== 'manager' && req.user.role !== 'stockist') return res.status(403).json({ error: "Forbidden" });
    const { name, price, stock } = req.body;
    db.prepare("UPDATE products SET name = ?, price = ?, stock = ? WHERE id = ?").run(name, price, stock, req.params.id);
    res.json({ success: true });
  });

  app.delete("/api/products/:id", authenticate, (req: any, res) => {
    if (req.user.role !== 'manager' && req.user.role !== 'stockist') return res.status(403).json({ error: "Forbidden" });
    
    try {
      const result = db.prepare("DELETE FROM products WHERE id = ?").run(req.params.id);
      if (result.changes === 0) {
        return res.status(404).json({ error: "Produto não encontrado." });
      }
      res.json({ success: true });
    } catch (e: any) {
      console.error("Erro ao excluir produto:", e);
      res.status(500).json({ error: "Erro ao excluir: " + e.message });
    }
  });

  // Clients
  app.get("/api/clients", authenticate, (req, res) => {
    const clients = db.prepare("SELECT * FROM clients").all();
    res.json(clients);
  });

  app.post("/api/clients", authenticate, (req: any, res) => {
    if (req.user.role !== 'manager' && req.user.role !== 'seller') return res.status(403).json({ error: "Forbidden" });
    const { name, phone } = req.body;
    const result = db.prepare("INSERT INTO clients (name, phone) VALUES (?, ?)").run(name, phone);
    res.json({ id: result.lastInsertRowid });
  });

  app.put("/api/clients/:id", authenticate, (req: any, res) => {
    if (req.user.role !== 'manager' && req.user.role !== 'seller') return res.status(403).json({ error: "Forbidden" });
    const { name, phone } = req.body;
    db.prepare("UPDATE clients SET name = ?, phone = ? WHERE id = ?").run(name, phone, req.params.id);
    res.json({ success: true });
  });

  app.delete("/api/clients/:id", authenticate, (req: any, res) => {
    if (req.user.role !== 'manager' && req.user.role !== 'seller') return res.status(403).json({ error: "Forbidden" });
    const client = db.prepare("SELECT name FROM clients WHERE id = ?").get(req.params.id) as any;
    if (client?.name === 'Consumidor Final') return res.status(400).json({ error: "Não é possível excluir o Consumidor Final" });
    db.prepare("DELETE FROM clients WHERE id = ?").run(req.params.id);
    res.json({ success: true });
  });

  // Sales
  app.post("/api/sales", authenticate, (req: any, res) => {
    if (req.user.role !== 'manager' && req.user.role !== 'seller') return res.status(403).json({ error: "Forbidden" });
    const { client_id, items, total } = req.body;

    const transaction = db.transaction(() => {
      // Check stock
      for (const item of items) {
        const product = db.prepare("SELECT stock FROM products WHERE id = ?").get(item.product_id) as any;
        if (!product || product.stock < item.quantity) {
          throw new Error(`Estoque insuficiente para o produto ID ${item.product_id}`);
        }
      }

      // Create sale
      const saleResult = db.prepare("INSERT INTO sales (client_id, total, user_id) VALUES (?, ?, ?)").run(client_id, total, req.user.id);
      const saleId = saleResult.lastInsertRowid;

      // Create items and update stock
      for (const item of items) {
        db.prepare("INSERT INTO sale_items (sale_id, product_id, quantity, price) VALUES (?, ?, ?, ?)").run(saleId, item.product_id, item.quantity, item.price);
        db.prepare("UPDATE products SET stock = stock - ? WHERE id = ?").run(item.quantity, item.product_id);
      }
      return saleId;
    });

    try {
      const saleId = transaction();
      res.json({ id: saleId });
    } catch (e: any) {
      res.status(400).json({ error: e.message });
    }
  });

  // Dashboard
  app.get("/api/dashboard", authenticate, (req: any, res) => {
    if (req.user.role !== 'manager') return res.status(403).json({ error: "Forbidden" });
    
    const today = new Date().toISOString().split('T')[0];
    const salesToday = db.prepare("SELECT SUM(total) as total FROM sales WHERE date >= ?").get(today) as any;
    const lowStock = db.prepare("SELECT * FROM products WHERE stock < 10").all();
    const recentSales = db.prepare(`
      SELECT s.*, c.name as client_name 
      FROM sales s 
      JOIN clients c ON s.client_id = c.id 
      ORDER BY s.date DESC LIMIT 5
    `).all();

    res.json({
      totalSalesToday: salesToday.total || 0,
      lowStockProducts: lowStock,
      recentSales
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
