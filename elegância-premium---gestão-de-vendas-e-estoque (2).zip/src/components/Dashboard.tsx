import { useState, useEffect } from 'react';
import { TrendingUp, Package, ShoppingBag, AlertTriangle, Clock } from 'lucide-react';
import { formatCurrency } from '../lib/utils';
import { motion } from 'motion/react';
import { mockService } from '../services/mockData';

type DashboardData = {
  totalSalesToday: number;
  lowStockProducts: any[];
  recentSales: any[];
};

export default function Dashboard() {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulating API delay
    const timer = setTimeout(() => {
      const dashboardData = mockService.getDashboardData();
      setData(dashboardData);
      setLoading(false);
    }, 300);
    return () => clearTimeout(timer);
  }, []);

  if (loading) return <div className="animate-pulse space-y-8">
    <div className="h-32 bg-zinc-200 rounded-2xl"></div>
    <div className="grid grid-cols-2 gap-8">
      <div className="h-64 bg-zinc-200 rounded-2xl"></div>
      <div className="h-64 bg-zinc-200 rounded-2xl"></div>
    </div>
  </div>;

  return (
    <div className="space-y-8">
      <header>
        <h2 className="text-3xl font-bold text-zinc-900">Dashboard</h2>
        <p className="text-zinc-500">Visão geral do sistema Elegancia premium</p>
      </header>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-zinc-100">
          <div className="flex items-center gap-4 mb-4">
            <div className="p-3 bg-orange-100 text-orange-600 rounded-xl">
              <TrendingUp size={24} />
            </div>
            <h3 className="font-semibold text-zinc-500">Vendas Hoje</h3>
          </div>
          <p className="text-3xl font-bold text-zinc-900">{formatCurrency(data?.totalSalesToday || 0)}</p>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-zinc-100">
          <div className="flex items-center gap-4 mb-4">
            <div className="p-3 bg-blue-100 text-blue-600 rounded-xl">
              <Package size={24} />
            </div>
            <h3 className="font-semibold text-zinc-500">Estoque Baixo</h3>
          </div>
          <p className="text-3xl font-bold text-zinc-900">{data?.lowStockProducts.length || 0}</p>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-zinc-100 sm:col-span-2 lg:col-span-1">
          <div className="flex items-center gap-4 mb-4">
            <div className="p-3 bg-green-100 text-green-600 rounded-xl">
              <ShoppingBag size={24} />
            </div>
            <h3 className="font-semibold text-zinc-500">Status</h3>
          </div>
          <p className="text-3xl font-bold text-zinc-900">Operacional</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Recent Sales */}
        <div className="bg-white rounded-2xl shadow-sm border border-zinc-100 overflow-hidden">
          <div className="p-6 border-b border-zinc-100 flex items-center justify-between">
            <h3 className="font-bold flex items-center gap-2">
              <Clock size={20} className="text-zinc-400" />
              Vendas Recentes
            </h3>
          </div>
          <div className="divide-y divide-zinc-50">
            {data?.recentSales.map((sale) => (
              <div key={sale.id} className="p-4 hover:bg-zinc-50 transition-colors flex items-center justify-between">
                <div>
                  <p className="font-medium text-zinc-900">{sale.client_name}</p>
                  <p className="text-xs text-zinc-500">{new Date(sale.date).toLocaleString('pt-BR')}</p>
                </div>
                <p className="font-bold text-orange-600">{formatCurrency(sale.total)}</p>
              </div>
            ))}
            {data?.recentSales.length === 0 && (
              <div className="p-8 text-center text-zinc-400 italic">Nenhuma venda registrada hoje.</div>
            )}
          </div>
        </div>

        {/* Low Stock Alerts */}
        <div className="bg-white rounded-2xl shadow-sm border border-zinc-100 overflow-hidden">
          <div className="p-6 border-b border-zinc-100 flex items-center justify-between">
            <h3 className="font-bold flex items-center gap-2">
              <AlertTriangle size={20} className="text-orange-500" />
              Alertas de Estoque
            </h3>
          </div>
          <div className="divide-y divide-zinc-50">
            {data?.lowStockProducts.map((product) => (
              <div key={product.id} className="p-4 hover:bg-zinc-50 transition-colors flex items-center justify-between">
                <div>
                  <p className="font-medium text-zinc-900">{product.name}</p>
                  <p className="text-xs text-zinc-500">ID: {product.id}</p>
                </div>
                <div className="text-right">
                  <p className="font-bold text-red-500">{product.stock} un.</p>
                  <p className="text-[10px] uppercase font-bold text-zinc-400">Repor urgente</p>
                </div>
              </div>
            ))}
            {data?.lowStockProducts.length === 0 && (
              <div className="p-8 text-center text-zinc-400 italic">Todos os produtos com estoque em dia.</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
