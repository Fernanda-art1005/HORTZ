import React, { useState, useEffect, useMemo } from 'react';
import { Search, ShoppingCart, Trash2, CheckCircle, User, Package, Minus, Plus } from 'lucide-react';
import { formatCurrency } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';
import { mockService, Product, Client } from '../services/mockData';

type CartItem = Product & {
  quantity: number;
};

export default function PDV() {
  const [products, setProducts] = useState<Product[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [search, setSearch] = useState('');
  const [selectedClientId, setSelectedClientId] = useState<number>(1); // Default to Consumidor Final
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    const p = mockService.getProducts();
    const c = mockService.getClients();
    setProducts(p);
    setClients(c);
    // Find Consumidor Final ID
    const cf = c.find((client: any) => client.name === 'Consumidor Final');
    if (cf) setSelectedClientId(cf.id);
  }, []);

  const addToCart = (product: Product) => {
    if (product.stock <= 0) return;
    
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        if (existing.quantity >= product.stock) {
          alert('Quantidade máxima em estoque atingida.');
          return prev;
        }
        return prev.map(item => 
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { ...product, quantity: 1 }];
    });
  };

  const removeFromCart = (productId: number) => {
    setCart(prev => prev.filter(item => item.id !== productId));
  };

  const updateQuantity = (productId: number, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === productId) {
        const newQty = item.quantity + delta;
        const product = products.find(p => p.id === productId);
        if (newQty > 0 && product && newQty <= product.stock) {
          return { ...item, quantity: newQty };
        }
      }
      return item;
    }));
  };

  const total = useMemo(() => 
    cart.reduce((sum, item) => sum + (item.price * item.quantity), 0)
  , [cart]);

  const handleFinalize = async () => {
    if (cart.length === 0) return;
    setLoading(true);

    // Simulating API delay
    setTimeout(() => {
      try {
        mockService.saveSale({
          client_id: selectedClientId,
          total,
          items: cart.map(item => ({
            product_id: item.id,
            quantity: item.quantity,
            price: item.price
          }))
        });

        setSuccess(true);
        setCart([]);
        // Refresh products to update stock
        setProducts(mockService.getProducts());
        
        setTimeout(() => setSuccess(false), 3000);
      } catch (err) {
        alert('Erro ao finalizar venda');
      } finally {
        setLoading(false);
      }
    }, 500);
  };

  const filteredProducts = products.filter(p => 
    p.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="flex flex-col lg:grid lg:grid-cols-3 gap-8 h-full lg:h-[calc(100vh-160px)]">
      {/* Product Selection */}
      <div className="lg:col-span-2 flex flex-col gap-6">
        <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <h2 className="text-3xl font-bold text-zinc-900">PDV</h2>
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" size={18} />
            <input
              type="text"
              placeholder="Buscar produto..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-white border border-zinc-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 transition-all text-sm"
            />
          </div>
        </header>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 overflow-y-auto pr-2 pb-4 lg:pb-0">
          {filteredProducts.map((product) => (
            <button
              key={product.id}
              onClick={() => addToCart(product)}
              disabled={product.stock <= 0}
              className={`p-4 bg-white border border-zinc-100 rounded-2xl text-left transition-all hover:shadow-md hover:border-orange-200 group relative ${
                product.stock <= 0 ? 'opacity-50 grayscale cursor-not-allowed' : ''
              }`}
            >
              <div className="mb-3 p-3 bg-zinc-50 rounded-xl group-hover:bg-orange-50 transition-colors">
                <Package size={24} className="text-zinc-400 group-hover:text-orange-500" />
              </div>
              <h3 className="font-bold text-zinc-900 truncate">{product.name}</h3>
              <p className="text-orange-600 font-bold">{formatCurrency(product.price)}</p>
              <p className="text-[10px] text-zinc-400 mt-1 uppercase font-bold">Estoque: {product.stock}</p>
              
              {product.stock <= 0 && (
                <div className="absolute inset-0 flex items-center justify-center bg-white/60 rounded-2xl">
                  <span className="bg-red-500 text-white text-[10px] font-black px-2 py-1 rounded uppercase">Sem Estoque</span>
                </div>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Cart & Checkout */}
      <div className="bg-white rounded-3xl shadow-xl border border-zinc-100 flex flex-col overflow-hidden h-[600px] lg:h-full mb-8 lg:mb-0">
        <div className="p-6 border-b border-zinc-100 bg-zinc-50/50">
          <h3 className="font-bold flex items-center gap-2 text-lg">
            <ShoppingCart size={20} className="text-orange-500" />
            Carrinho de Vendas
          </h3>
        </div>

        <div className="p-4 border-b border-zinc-100">
          <label className="block text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-2">Selecionar Cliente</label>
          <div className="relative">
            <User className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" size={16} />
            <select
              value={selectedClientId}
              onChange={(e) => setSelectedClientId(parseInt(e.target.value))}
              className="w-full pl-10 pr-4 py-2 bg-zinc-50 border border-zinc-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 appearance-none text-sm font-medium"
            >
              {clients.map(client => (
                <option key={client.id} value={client.id}>{client.name}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          <AnimatePresence initial={false}>
            {cart.map((item) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="flex items-center gap-3 p-3 bg-zinc-50 rounded-2xl group"
              >
                <div className="flex-1 min-w-0">
                  <p className="font-bold text-zinc-900 truncate text-sm">{item.name}</p>
                  <p className="text-xs text-zinc-500">{formatCurrency(item.price)}</p>
                </div>
                
                <div className="flex items-center gap-2 bg-white border border-zinc-200 rounded-lg p-1">
                  <button 
                    onClick={() => updateQuantity(item.id, -1)}
                    className="p-1 hover:bg-zinc-100 rounded"
                  >
                    <Minus size={12} />
                  </button>
                  <span className="text-xs font-bold w-4 text-center">{item.quantity}</span>
                  <button 
                    onClick={() => updateQuantity(item.id, 1)}
                    className="p-1 hover:bg-zinc-100 rounded"
                  >
                    <Plus size={12} />
                  </button>
                </div>

                <button 
                  onClick={() => removeFromCart(item.id)}
                  className="p-2 text-zinc-300 hover:text-red-500 transition-colors"
                >
                  <Trash2 size={16} />
                </button>
              </motion.div>
            ))}
          </AnimatePresence>
          {cart.length === 0 && (
            <div className="h-full flex flex-col items-center justify-center text-zinc-300 gap-4">
              <ShoppingCart size={48} strokeWidth={1} />
              <p className="text-sm font-medium">Carrinho vazio</p>
            </div>
          )}
        </div>

        <div className="p-6 bg-[#f5f5f0] border-t border-zinc-200">
          <div className="flex justify-between items-end mb-6">
            <div>
              <p className="text-zinc-500 text-[10px] font-black uppercase tracking-widest">Total da Venda</p>
              <p className="text-3xl font-black text-orange-500">{formatCurrency(total)}</p>
            </div>
            <p className="text-zinc-500 text-xs">{cart.length} itens</p>
          </div>

          <button
            onClick={handleFinalize}
            disabled={cart.length === 0 || loading}
            className={`w-full py-4 rounded-2xl font-black uppercase tracking-widest text-white transition-all flex items-center justify-center gap-2 shadow-xl ${
              success 
                ? 'bg-green-500 shadow-green-500/20' 
                : 'bg-orange-600 hover:bg-orange-500 shadow-orange-600/20'
            } disabled:opacity-50 disabled:grayscale`}
          >
            {loading ? (
              <div className="h-5 w-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
            ) : success ? (
              <>
                <CheckCircle size={20} />
                Venda Realizada!
              </>
            ) : (
              'Finalizar Venda'
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
